---
title: "二次根式的乘法法则"
atom_type: "concept"
atom_key: "atom-derived-efa6655816ce5225"
owner_key: "topic-2-3-1"
source: "【2024版】【北师大版】八年级上册数学.pdf"
source_pdf: "【2024版】【北师大版】八年级上册数学.pdf"
source_sha256: "8623da3eeb077dd05fe6b020374dc13b47ea5197cbf798db6afdd2777ce1a33e"
source_range: [1340, 1344]
used_by:
  - "义务教育教科书 数学 八年级 上册（2024北师大版）"
  - "第二章 实数"
  - "3 二次根式"
  - "2.3.1 二次根式的概念与乘除运算"
organizers:
  - "义务教育教科书 数学 八年级 上册（2024北师大版）"
  - "第二章 实数"
  - "3 二次根式"
  - "2.3.1 二次根式的概念与乘除运算"
updated_at: "2026-11-13"
review_status: "passed"
estimated_learning_minutes: 2
difficulty: "reference"
importance: "reference"
learning_objectives:
  - "查阅：二次根式的乘法法则"
derived_from: "atom-963ea20ef84dad03"
derived_kind: "concept"
defined_in_file: "原子层/知识点/二次根式的乘法法则与除法法则--000022.md"
defined_in_title: "二次根式的乘法法则与除法法则"
concept_name: "二次根式的乘法法则"
concept_key: "concept-44795f291f3423cf"
concept_kind: "rule"
preferred_label: "二次根式的乘法法则"
definition_summary: "教材八年级上册关于“二次根式的乘法法则”的数学核心定义与性质规律陈述。"
chapter_title: "第二章 实数"
section_title: "2.3.1 二次根式的概念与乘除运算"
is_definition_card: true
aliases: []
prerequisite_concepts:
  - "二次根式"
related_concepts:
  - "二次根式的除法法则"
  - "二次根式"
applied_in_atoms:
  - "二次根式的乘法法则与除法法则"
---

二次根式的乘法法则和除法法则

$$
\sqrt {a} \cdot \sqrt {b} = \sqrt {a b} (a \geqslant 0, b \geqslant 0), \frac {\sqrt {a}}{\sqrt {b}} = \sqrt {\frac {a}{b}} (a \geqslant 0, b > 0) _ {\circ}
$$
